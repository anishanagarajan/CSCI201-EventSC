
public class RequestManager {
	float sessionID;
	User currUser;
	String request;
	
	public RequestManager(float mSessionID, User mCurrUser, String mRequest){
		sessionID = mSessionID;
		currUser = mCurrUser;
		request= mRequest;
	}
	public void callManager(){
		/*add code here*/
	}
}
